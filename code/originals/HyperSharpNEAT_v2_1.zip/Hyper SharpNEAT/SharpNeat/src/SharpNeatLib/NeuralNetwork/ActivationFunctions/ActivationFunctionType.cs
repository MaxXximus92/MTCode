using System;

namespace SharpNeatLib.NeuralNetwork
{
    public enum ActivationFunctionType
    {
        Sigmoid,
        Gaussian,
        Sin,
        Linear
    }
}