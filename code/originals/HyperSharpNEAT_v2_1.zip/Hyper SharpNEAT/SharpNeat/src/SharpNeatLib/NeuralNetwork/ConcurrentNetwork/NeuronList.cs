using System;
using System.Collections.Generic;

namespace SharpNeatLib.NeuralNetwork
{

	public class NeuronList : List<Neuron>
	{

	}
}
