using System;

namespace SharpNeatLib.NeatGenome
{
	public enum CorrelationItemType
	{
		MatchedConnectionGenes,
		DisjointConnectionGene,
		ExcessConnectionGene
	}
}
