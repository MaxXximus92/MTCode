using System;
using System.Collections;

namespace SharpNeatLib.AppConfig
{
	public class ExperimentConfigInfo
	{
		public string       Title;
		public string       Description;
		public string		AssemblyUrl;
		public string		TypeName;
		public Hashtable    ParameterTable;
	}
}
