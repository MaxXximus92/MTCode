using System;
using System.Collections.Generic;
using System.Text;

namespace Engine
{
    public enum SensorType
    {
        rangeFinder,
        radar,
		signal
    };
}
