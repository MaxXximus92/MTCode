// Main.cs created with MonoDevelop
// User: joel at 8:01 PM 5/13/2009
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//
using System;
using System.Windows.Forms;

namespace simulator
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			Application.Run(new sim_vis());
		}
	}
} 