using System;
using System.Collections.Generic;

namespace SharpNeatLib.NetworkVisualization
{

	public class ModelNeuronList : List<ModelNeuron>
	{
		
	}
}
