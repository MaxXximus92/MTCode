using System;
using System.Collections.Generic;

namespace SharpNeatLib.NeuralNetwork
{

	public class NetworkList : List<INetwork>
	{
		

	}
}
